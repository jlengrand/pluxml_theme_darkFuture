<?php
define('VIADEO', 'http://http://www.pluxml.org/' );
define('LINKEDIN', "http://www.pluxml.org/");
define('TWITTER', "http://www.pluxml.org/");
define('GP', "http://www.pluxml.org/");
define('MAILTO', "http://www.pluxml.org/");

define('FR', "http://www.pluxml.org/");
define('EN', "http://www.pluxml.org/");

define('DARTH', "http://www.pluxml.org/");
define('ARP', "http://www.pluxml.org/");
define('CRUNCH', "http://www.pluxml.org/");
define('DEBIAN', "http://www.debian.org/index.fr.html");
define('STACK', "http://www.pluxml.org/");

define('BLOG', "http://www.pluxml.org/");
define('ME', "http://www.pluxml.org/");
define('GALLERY', "http://www.pluxml.org/");
define('PRO', "http://www.pluxml.org/");
define('GITHUB', "https://github.com/jlengrand");
define('PROG', "http://lengrandlambert.fr/progTips.html");

define('VIADEO_H', "./themes/pluxml_theme_darkFuture/img/viadeo.png" );
define('LINKEDIN_H', "./themes/pluxml_theme_darkFuture/img/linkedin.png");
define('TWITTER_H', "./themes/pluxml_theme_darkFuture/img/twitter.png");
define('GP_H', "./themes/pluxml_theme_darkFuture/img/google-plus.png");
define('MAILTO_H', "./themes/pluxml_theme_darkFuture/img/mailto.png");
define('RSS_H', "./themes/pluxml_theme_darkFuture/img/rss.png");

define('CERTIF_H', "./themes/pluxml_theme_darkFuture/img/certificate.png");

define('FR_H', "./themes/pluxml_theme_darkFuture/img/fr.png");
define('EN_H', "./themes/pluxml_theme_darkFuture/img/en.png");

?>
